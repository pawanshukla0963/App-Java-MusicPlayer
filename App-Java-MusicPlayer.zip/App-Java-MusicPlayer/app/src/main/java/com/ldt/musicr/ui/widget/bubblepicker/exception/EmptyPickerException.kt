package com.ldt.musicr.ui.widget.bubblepicker.exception

/**
 * Created by irinagalata on 1/19/17.
 */
class EmptyPickerException : Exception("Picker must have at least one item when it becomes visible")