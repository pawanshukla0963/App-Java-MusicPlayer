package com.ldt.musicr.notification

object ActionKey {
    const val PLAY_ALL_SONGS = "PLAY_ALL_SONGS"
    const val SHOW_POPUP_OPTIONS = "SHOW_POPUP_OPTIONS"
    const val GET_PREVIEWING_SONG = "GET_PREVIEWING_SONG"
    const val GET_PLAYING_SONG = "GET_PLAYING_SONG"
}