package com.ldt.musicr.ui.widget.waveform.gesture;

/**
 * Created by trung on 9/7/2017.
 */

public interface OnDragGestureListener {
    void onDrag(float dx, float dy);
}